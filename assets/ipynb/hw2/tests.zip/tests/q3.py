OK_FORMAT = True

test = {   'name': 'q3',
    'points': None,
    'suites': [{'cases': [{'code': ">>> assert file_first_pos == 'pos/cv000_29590.txt'\n", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
