OK_FORMAT = True

test = {'name': 'q1', 'points': None, 'suites': [{'cases': [{'code': '>>> assert v2_year == 2004\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
