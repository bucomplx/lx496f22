OK_FORMAT = True

test = {'name': 'q0', 'points': None, 'suites': [{'cases': [{'code': '>>> assert first_answer == 10\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
