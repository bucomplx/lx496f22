OK_FORMAT = True

test = {   'name': 'q2',
    'points': None,
    'suites': [{'cases': [{'code': '>>> assert punc_words == list(string.punctuation)\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
