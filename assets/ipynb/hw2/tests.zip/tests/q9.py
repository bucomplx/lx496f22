OK_FORMAT = True

test = {   'name': 'q9',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> assert \'neg\' in [tw[1] for tw in tagged_tweets[:5000]], "tweets not randomized"\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert len(test_tweets) == 3000 and len(train_tweets) == 7000, "training and test sets wrong size"\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
